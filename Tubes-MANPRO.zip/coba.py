# -*- coding: utf-8 -*-
import sys
# # print ("yourmom")
result=int(sys.argv[1])
# #result=str(sys.argv)
print(result)