import sys
# print ("yourmom")
result=int(sys.argv[1]) + int(sys.argv[2])
#result=str(sys.argv)
print(result)

